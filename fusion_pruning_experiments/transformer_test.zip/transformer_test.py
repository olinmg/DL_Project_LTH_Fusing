from fusion import get_ground_metric
from pruning_modified import prune_structured
import torch
from torch.nn import functional as F
from datasets import load_dataset
from transformers import AutoModelForCausalLM, GPT2Model, AutoTokenizer, GPTNeoForCausalLM
import torchmetrics
from tqdm import tqdm
import copy
import numpy as np
import ot

def get_histogram(cardinality, indices, add=False):

    if add == False:
        return np.ones(cardinality)/cardinality # uniform probability distribution

    else:
        result = np.ones(cardinality)
        for indice in indices:
            result[indice] = cardinality/indices.size()[0]

        return result/np.sum(result)

# replace this with any model you like
# popular models include [gpt2, gpt2-large, gpt2-medium, gpt2-xl]
# pythia, gpt-neo etc ...

model = AutoModelForCausalLM.from_pretrained("gpt2")

print(model)


# we can only focus on these
i = 0 # range(len(model.transformer.h))
print(model.transformer.h[0])
print(model.transformer.h[i].mlp)
print("----------------")
for name, module in model.named_modules():

    print(f"Name: {name}")
    print(f"Module : {module}")
    print("*****************")
# There is also a dropout layer, but in eval mode should be easy to remove 



# We can prune these
# model.transformer.h[i].mlp.c_fc, model.transformer.h[i].mlp.c_proj

### Evaluate
# Typical ways to evaluate (see more https://github.com/EleutherAI/lm-evaluation-harness) 
# include word perplexity, loss, accuracy etc ..
# Here https://arxiv.org/pdf/2301.00774.pdf they also focus on perplexity


def collate_fn(batch):
    input_ids = torch.tensor([b["input_ids"] for b in batch])
    targets = torch.roll(input_ids, -1, dims=-1)
    # here we ignore masking as it is already taken care of in the dataset
    targets[:, -1] = -1  # ignore index is set to -1
    return input_ids, targets

# a dataset of wikitext and bookcorpus that is alraedy pre-processed
dataset = load_dataset("sanagnos/processed_gpt_dataset_big", split="train[0:1000]")

# This is what a random sample looks like, text with 1-24 tokens
tokenizer = AutoTokenizer.from_pretrained("gpt2")



dataloader = torch.utils.data.DataLoader(dataset, batch_size=4, shuffle=False, collate_fn=collate_fn)

"""t = prune_structured(net=copy.deepcopy(model), loaders=None, num_epochs=0, gpu_id=0, example_inputs=torch.arange(0, 1024),
                    out_features=50257, prune_type="l1", sparsity=0.5, train_fct=None)"""
print("----------------")
x = torch.rand(4, 1024, 768)
print(x.size()[:-1] + (3072,))
print("HerE: ", x.view(-1, x.size(-1)).shape)

print(model.transformer.h[0].mlp.c_fc.weight.shape)
print(model.transformer.h[0].mlp.c_proj.weight.shape)
print("Bias: ", model.transformer.h[0].mlp.c_fc.bias.shape)
ch = 2150
incl = 3072
print("This is how it could look: ", model.transformer.h[0].mlp.c_fc.weight[:,:ch].shape)

for i in range(len(model.transformer.h)):
    weight_fc = model.transformer.h[i].mlp.c_fc.weight
    bias_fc = model.transformer.h[i].mlp.c_fc.bias
    weight_proj = model.transformer.h[i].mlp.c_proj.weight

    norm_layer = torch.norm(weight_fc, p=1, dim=0)
    norm_layer_proj = torch.norm(weight_proj, p=1, dim=1)
    norm_layer = (norm_layer + norm_layer_proj)/2
    print("norm_layer shape: ", norm_layer.shape)
    print(norm_layer)

    #_, indices = torch.topk(norm_layer, ch)
    #indices = indices[-ch:]
    indices = torch.arange(0, ch)
    #indices = torch.randperm(3072)[:ch]
    print("indices shape: ", indices.shape)

    comp_vec = [weight_fc.t(), weight_proj]
    basis_vec = [torch.index_select(weight_fc, 1, indices).t(), torch.index_select(weight_proj, 0, indices)]
    print("have comp and basis vec")

    
    M = []
    M.append(get_ground_metric(comp_vec[0].clone(), basis_vec[0].clone(), None, None))
    M.append(get_ground_metric(comp_vec[1].clone(), basis_vec[1].clone(), None, None))
    M = torch.stack(M)
    M = torch.mean(M, dim=0)
    
    print("We now have M: ", M.shape)
    
    mu = get_histogram(basis_vec[0].shape[0], indices = None)

    #nu = norm_layer.cpu().numpy()/np.sum(norm_layer.cpu().numpy())
    #nu = get_histogram(comp_vec[0].shape[0], indices = None)
    nu = get_histogram(comp_vec[0].shape[0], indices = indices, add=True)

    cpuM = M.data.cpu().numpy() # POT does not accept array on GPU

    T = ot.emd(nu, mu, cpuM)  

    #T_var *= get_histogram(comp_vec[0].shape[0], indices = indices, add=False)[:,None]
    T_var = torch.from_numpy(T).float()
    T_var = T_var / T_var.sum(dim=0)


    print("T_Var shape: ", T_var.shape)

    def align(aligned_wt):
        return torch.matmul(T_var.t(), aligned_wt.contiguous().view(aligned_wt.shape[0], -1))
    
    weight_fc = align(weight_fc.t()).t()
    bias_fc = align(bias_fc).view(-1)
    weight_proj = align(weight_proj)
    
    print(weight_fc.shape)
    print(bias_fc.shape)
    print(weight_proj.shape)


    model.transformer.h[i].mlp.c_fc.weight = torch.nn.Parameter(weight_fc)
    model.transformer.h[i].mlp.c_fc.bias = torch.nn.Parameter(bias_fc)
    model.transformer.h[i].mlp.c_proj.weight = torch.nn.Parameter(weight_proj)
    model.transformer.h[i].mlp.c_fc.nf = ch

    #print(torch.index_select(model.transformer.h[i].mlp.c_fc.weight, 1, indices).shape)
    """model.transformer.h[i].mlp.c_fc.weight = torch.nn.Parameter(torch.index_select(weight_fc, 1, indices))

    model.transformer.h[i].mlp.c_fc.bias = torch.nn.Parameter(torch.index_select(bias_fc, 0, indices))

    model.transformer.h[i].mlp.c_fc.nf = ch
    model.transformer.h[i].mlp.c_proj.weight = torch.nn.Parameter(torch.index_select(weight_proj, 0, indices))"""

print("We have: ", len(model.transformer.h))
def eval_model(model, test_dataloader, max_iters=None):
    model.eval()

    total = 0
    losses = []
    accs = []
    
    device = model.device
    
    for cnt, test_inputs in tqdm(enumerate(test_dataloader)):
        input_ids, targets = test_inputs[0].to(device), test_inputs[1].to(device)
        #print("targets shape: ", targets.shape)

        with torch.no_grad():
            logits = model(input_ids).logits
            perplexity = torchmetrics.text.perplexity.Perplexity(ignore_index=-1).to(device)
            #print("logits is: ", logits.shape)
            loss = perplexity(
                logits, targets
            )

        losses.append(loss.item() * input_ids.shape[0])

        preds = torch.argmax(logits, axis=-1)
        acc = (preds == targets).float().mean().item() * input_ids.shape[0]

        accs.append(acc)
        
        total += input_ids.shape[0]

        if max_iters is not None and cnt >= max_iters:
            break

    return sum(losses) / total, sum(accs) / total


model.cuda();
accuracy = eval_model(model, dataloader)
print(f"Accuracy is: {accuracy}")

# some people just report perplexity, maybe we should do the same
# some people also ignore the first tokens in the sequence as these have a smaller context window